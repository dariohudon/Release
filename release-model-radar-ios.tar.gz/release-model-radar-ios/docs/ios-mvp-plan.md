# Release Model Radar iOS — architecture notes

## Principles

- **The web app is the source of truth.** This app never duplicates the
  catalog; it renders whatever `release.brightening.ca` serves. Catalog
  edits happen in the web repo (`lib/models/data.ts`) and flow here on the
  next fetch.
- **Read-only.** The public API has no mutation endpoints and this app adds
  none. The daily update checker stays cron-only on the server; the app only
  reads its status summary.
- **Nothing private.** No server paths, no candidate-review files, no logs,
  no keys. Everything the app touches is already public.

## API contract

Base: `https://release.brightening.ca`

Envelope (see the web repo's `lib/api/types.ts`):

```json
{ "ok": true, "generatedAt": "ISO", "count": 0, "data": {} }
{ "ok": false, "generatedAt": "ISO", "error": "short safe message", "data": null }
```

| Endpoint | Swift payload type | Used by |
|---|---|---|
| `/api/models` | `ModelsPayload` | Radar tab |
| `/api/labs` | `LabsPayload` | Labs tab + lab colors on Radar |
| `/api/definitions` | `DefinitionsPayload` | Definitions tab |
| `/api/update-status` | `UpdateStatus` | toolbar badge (404 envelope = "Not checked yet") |
| `/api/news` | `NewsPayload` | News tab |

## MVP structure

```
ReleaseModelRadar/
  ReleaseModelRadarApp.swift   app entry, TabView, dark scheme
  Theme.swift                  radar.css tokens + date helpers
  API/
    APIClient.swift            actor, async/await, envelope decode,
                               in-memory last-good-response fallback
    APIModels.swift            Decodable mirrors of the TS interfaces
  Components/
    StateViews.swift           LoadingView, ErrorView(retry), Pill
    StatusBadge.swift          last-checked toolbar badge
  Features/
    Models/ModelsView.swift    grouped catalog list
    Models/ModelDetailView.swift
    Labs/LabsView.swift
    Definitions/DefinitionsView.swift  (searchable, expandable)
    News/NewsView.swift
```

State pattern: each screen owns `@State var state: Loadable<Payload>` and a
`load(force:)` — no view-model layer yet; introduce one when Phase 2 adds
persistence and favourites.

## Phase 2

- Persistent offline cache (store last good JSON per endpoint on disk)
- Saved/favourite models (local only)
- Better iPad layout (NavigationSplitView)
- Background refresh (BGAppRefreshTask) if appropriate

## Phase 3

- Widgets (latest release, last-checked)
- Local notifications for "daily check completed" via `/api/update-status`
- Optional push notifications later (needs server work — out of scope)

## Security / privacy

- The API domain in the binary is fine — it is public.
- Never reference Leonard/server internals in code, strings, or docs here.
- No secrets exist in this app; keep it that way.
