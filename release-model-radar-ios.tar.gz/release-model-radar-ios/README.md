# Release Model Radar — iOS

Native SwiftUI client for [Release Model Radar](https://release.brightening.ca).
The web app remains the source of truth; this app only consumes its public,
read-only JSON API. No keys, no auth, no mutation, no scraping.

## Requirements

- Xcode 16 or newer (the project uses the folder-synchronized project format)
- iOS 17.0+ deployment target
- No external dependencies — pure SwiftUI + Foundation

## Run it

1. Open `ReleaseModelRadar.xcodeproj` in Xcode.
2. Pick an iPhone simulator (no signing needed) and press ⌘R.
3. To run on a device, select your personal team under
   Signing & Capabilities → Team.

If Xcode ever refuses the project file (it was authored outside Xcode):
create a fresh iOS App project named `ReleaseModelRadar` (SwiftUI, Swift),
delete its generated source files, and drag this repo's `ReleaseModelRadar/`
folder contents in. Every Swift file is self-contained.

## What it shows

| Tab | API | Notes |
|---|---|---|
| Radar | `/api/models` + `/api/labs` | Release timeline (lab-colored dots, dashed horizon dots, today marker — tap a dot for the detail); sections: Just shipped / Live now / On the horizon; verdict pills; tap for the full read-out (strengths, watch-outs, pricing, sentiment, link) |
| Labs | `/api/labs` | Name, brand color, model count |
| Definitions | `/api/definitions` | Search across term / aliases / definitions; tap to expand Plain English · Why it matters · Example |
| News | `/api/news` | Newest first, official vs news-search tags, unreachable labs notice, outbound links |

The Radar toolbar shows the **last-checked badge** from `/api/update-status`:
"Checked Jun 11", "Stale · Jun 11" past 36 h (amber, like the web), or
"Not checked yet" when the API has no run recorded. Tap it for the full
detail line.

## Architecture (MVP)

- `API/APIClient.swift` — one actor, async/await, shared `{ ok, generatedAt,
  count, data }` envelope decoding, 15 s timeouts. The last successful
  response per endpoint is cached **in memory only** and used as a fallback
  when the network fails (persistent cache is Phase 4).
- `API/APIModels.swift` — `Decodable` mirrors of the web app's TypeScript
  interfaces. If the web data model changes, update here.
- Each tab owns its `Loadable<T>` state (`loading / loaded / failed`) with
  pull-to-refresh and a Retry button on errors.
- `Theme.swift` — the web app's `radar.css` dark-navy tokens as SwiftUI colors.

See `docs/ios-mvp-plan.md` for the phase plan.

## Out of scope for this MVP (deliberately)

App Store signing, widgets, push notifications, accounts/auth, favourites,
and persistent offline cache — see Phases 2–3 in the plan.
