import XCTest
@testable import ReleaseModelRadar

/// Intercepts the APIClient's URLSession so cache policy can be tested
/// without any network. Each test sets `handler` before fetching.
final class MockURLProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> (HTTPURLResponse, Data))?

    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }

    override func startLoading() {
        guard let handler = MockURLProtocol.handler else {
            client?.urlProtocol(self, didFailWithError: URLError(.badServerResponse))
            return
        }
        do {
            let (response, data) = try handler(request)
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch {
            client?.urlProtocol(self, didFailWithError: error)
        }
    }

    override func stopLoading() {}
}

final class APIClientCachePolicyTests: XCTestCase {

    struct Payload: Codable, Equatable {
        let value: String
    }

    private var cacheDirectory = ""

    override func setUp() {
        super.setUp()
        cacheDirectory = "Test-\(UUID().uuidString)"
        MockURLProtocol.handler = nil
    }

    override func tearDown() {
        MockURLProtocol.handler = nil
        super.tearDown()
    }

    private func makeClient() -> APIClient {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [MockURLProtocol.self]
        return APIClient(
            configuration: configuration,
            diskCache: LocalAPIResponseCache(directoryName: cacheDirectory)
        )
    }

    private func respond(status: Int, body: String) {
        MockURLProtocol.handler = { request in
            let response = HTTPURLResponse(
                url: request.url!, statusCode: status, httpVersion: nil, headerFields: nil
            )!
            return (response, Data(body.utf8))
        }
    }

    private func failNetwork() {
        MockURLProtocol.handler = { _ in throw URLError(.notConnectedToInternet) }
    }

    private let goodA = #"{"ok":true,"generatedAt":"2026-06-12T00:00:00.000Z","count":1,"data":{"value":"A"}}"#

    func test_freshFetchReturnsFreshAndWritesCache() async throws {
        let client = makeClient()
        respond(status: 200, body: goodA)

        let outcome = try await client.fetchWithCache("/api/test", as: Payload.self)
        XCTAssertEqual(outcome.value, Payload(value: "A"))
        guard case .fresh = outcome.source else { return XCTFail("expected .fresh") }

        // Network gone → the just-written cache must answer.
        failNetwork()
        let fallback = try await client.fetchWithCache("/api/test", as: Payload.self)
        XCTAssertEqual(fallback.value, Payload(value: "A"))
        guard case .cached = fallback.source else { return XCTFail("expected .cached") }
    }

    func test_decodeFailureDoesNotOverwriteGoodCache() async throws {
        let client = makeClient()
        respond(status: 200, body: goodA)
        _ = try await client.fetchWithCache("/api/test", as: Payload.self)

        // Server now returns garbage: the fetch must fall back to the good
        // cached value, and the garbage must NOT replace it.
        respond(status: 200, body: "not json at all")
        let outcome = try await client.fetchWithCache("/api/test", as: Payload.self)
        XCTAssertEqual(outcome.value, Payload(value: "A"))
        guard case .cached = outcome.source else { return XCTFail("expected .cached") }

        // Still good after another failure round (cache was not poisoned).
        failNetwork()
        let again = try await client.fetchWithCache("/api/test", as: Payload.self)
        XCTAssertEqual(again.value, Payload(value: "A"))
    }

    func test_authoritativeOkFalseIsNotMaskedByCache() async throws {
        let client = makeClient()
        respond(status: 200, body: goodA)
        _ = try await client.fetchWithCache("/api/test", as: Payload.self)

        // ok:false is a real server answer — stale cache must not hide it.
        respond(status: 404, body: #"{"ok":false,"generatedAt":"2026-06-12T00:00:00.000Z","error":"no update check recorded yet","data":null}"#)
        do {
            _ = try await client.fetchWithCache("/api/test", as: Payload.self)
            XCTFail("expected APIError.api to be thrown")
        } catch let error as APIError {
            guard case .api(let message) = error else { return XCTFail("expected .api, got \(error)") }
            XCTAssertEqual(message, "no update check recorded yet")
        }
    }

    func test_diskCacheServesAfterClientRecreation() async throws {
        let first = makeClient()
        respond(status: 200, body: goodA)
        _ = try await first.fetchWithCache("/api/test", as: Payload.self)

        // New client, empty memory, same disk directory, no network:
        // the disk cache must answer.
        let second = makeClient()
        failNetwork()
        let outcome = try await second.fetchWithCache("/api/test", as: Payload.self)
        XCTAssertEqual(outcome.value, Payload(value: "A"))
        guard case .cached(let savedAt) = outcome.source else { return XCTFail("expected .cached") }
        XCTAssertLessThanOrEqual(abs(savedAt.timeIntervalSinceNow), 60)
    }
}
