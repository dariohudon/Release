import XCTest
@testable import ReleaseModelRadar

final class LocalAPIResponseCacheTests: XCTestCase {

    private func makeCache() -> LocalAPIResponseCache {
        LocalAPIResponseCache(directoryName: "Test-\(UUID().uuidString)")
    }

    func test_saveAndLoadRoundtrip() async {
        let cache = makeCache()
        let payload = Data("hello".utf8)
        await cache.save(payload, for: "/api/models")
        let loaded = await cache.load(for: "/api/models")
        XCTAssertEqual(loaded?.data, payload)
        XCTAssertNotNil(loaded?.savedAt)
    }

    func test_missingEntryReturnsNil() async {
        let cache = makeCache()
        let loaded = await cache.load(for: "/api/never-written")
        XCTAssertNil(loaded)
    }

    /// The old sanitization collapsed "/api/a-b" and "/api/a/b" to the same
    /// filename; the hashed scheme must keep them distinct.
    func test_similarPathsDoNotCollide() async {
        let cache = makeCache()
        await cache.save(Data("dash".utf8), for: "/api/a-b")
        await cache.save(Data("slash".utf8), for: "/api/a/b")
        let dash = await cache.load(for: "/api/a-b")
        let slash = await cache.load(for: "/api/a/b")
        XCTAssertEqual(dash.map { String(decoding: $0.data, as: UTF8.self) }, "dash")
        XCTAssertEqual(slash.map { String(decoding: $0.data, as: UTF8.self) }, "slash")
    }

    /// Disk entries must survive recreating the cache (≈ app relaunch).
    func test_persistsAcrossInstances() async {
        let directory = "Test-\(UUID().uuidString)"
        let first = LocalAPIResponseCache(directoryName: directory)
        await first.save(Data("persisted".utf8), for: "/api/labs")

        let second = LocalAPIResponseCache(directoryName: directory)
        let loaded = await second.load(for: "/api/labs")
        XCTAssertEqual(loaded.map { String(decoding: $0.data, as: UTF8.self) }, "persisted")
    }
}
