import XCTest
@testable import ReleaseModelRadar

@MainActor
final class LabFavoritesStoreTests: XCTestCase {

    private var suiteName = ""
    private var defaults: UserDefaults!

    override func setUp() {
        super.setUp()
        suiteName = "test.favorites.\(UUID().uuidString)"
        defaults = UserDefaults(suiteName: suiteName)
    }

    override func tearDown() {
        defaults.removePersistentDomain(forName: suiteName)
        super.tearDown()
    }

    private func lab(_ id: String, count: Int) -> Lab {
        Lab(id: id, name: id.capitalized, color: "#5EEAD4", modelCount: count)
    }

    private func newsItem(lab: String, title: String) -> NewsItem {
        NewsItem(
            id: "\(lab)-0", lab: lab, labName: lab.capitalized, title: title,
            url: "https://example.com", source: "Official", sourceType: "official",
            publishedAt: nil, snippet: nil
        )
    }

    func test_favouritesPersistAcrossStoreRecreation() {
        let first = LabFavoritesStore(defaults: defaults)
        first.toggle("anthropic")
        XCTAssertTrue(first.isFavorite("anthropic"))

        let second = LabFavoritesStore(defaults: defaults)
        XCTAssertTrue(second.isFavorite("anthropic"))

        second.toggle("anthropic")
        let third = LabFavoritesStore(defaults: defaults)
        XCTAssertFalse(third.isFavorite("anthropic"))
    }

    func test_snapshotsPersistAndFlagChangesForFavouritesOnly() {
        let first = LabFavoritesStore(defaults: defaults)
        first.toggle("anthropic")
        first.recordLabsSnapshot([lab("anthropic", count: 5), lab("google", count: 4)])
        XCTAssertTrue(first.newInfoLabIDs.isEmpty, "first snapshot must not flag")

        // Recreate (≈ relaunch): the snapshot must have persisted, so a
        // changed count flags the favourited lab — and only that one.
        let second = LabFavoritesStore(defaults: defaults)
        second.recordLabsSnapshot([lab("anthropic", count: 6), lab("google", count: 9)])
        XCTAssertEqual(second.newInfoLabIDs, ["anthropic"])

        // Indicator itself persists across recreation too.
        let third = LabFavoritesStore(defaults: defaults)
        XCTAssertEqual(third.newInfoLabIDs, ["anthropic"])
        third.clearNewInfo(for: "anthropic")
        XCTAssertTrue(third.newInfoLabIDs.isEmpty)
    }

    func test_newsSnapshotFlagsNewHeadlineForFavourites() {
        let store = LabFavoritesStore(defaults: defaults)
        store.toggle("openai")
        store.recordNewsSnapshot([newsItem(lab: "openai", title: "first headline")])
        XCTAssertTrue(store.newInfoLabIDs.isEmpty, "first snapshot must not flag")

        store.recordNewsSnapshot([newsItem(lab: "openai", title: "second headline")])
        XCTAssertEqual(store.newInfoLabIDs, ["openai"])
    }

    func test_vanishedLabIsPrunedSafely() {
        let store = LabFavoritesStore(defaults: defaults)
        store.toggle("ghostlab")
        store.recordLabsSnapshot([lab("ghostlab", count: 3), lab("anthropic", count: 5)])
        store.recordLabsSnapshot([lab("ghostlab", count: 4), lab("anthropic", count: 5)])
        XCTAssertEqual(store.newInfoLabIDs, ["ghostlab"])

        // Lab disappears upstream: favourite, indicator, and snapshot entry
        // must all be cleaned up without crashing.
        store.recordLabsSnapshot([lab("anthropic", count: 5)])
        XCTAssertFalse(store.isFavorite("ghostlab"))
        XCTAssertTrue(store.newInfoLabIDs.isEmpty)

        // And the cleanup persisted.
        let reloaded = LabFavoritesStore(defaults: defaults)
        XCTAssertFalse(reloaded.isFavorite("ghostlab"))
        XCTAssertTrue(reloaded.newInfoLabIDs.isEmpty)
    }

    func test_unfavouritingClearsItsIndicator() {
        let store = LabFavoritesStore(defaults: defaults)
        store.toggle("meta")
        store.recordLabsSnapshot([lab("meta", count: 2)])
        store.recordLabsSnapshot([lab("meta", count: 3)])
        XCTAssertEqual(store.newInfoLabIDs, ["meta"])

        store.toggle("meta")
        XCTAssertTrue(store.newInfoLabIDs.isEmpty)
    }
}
