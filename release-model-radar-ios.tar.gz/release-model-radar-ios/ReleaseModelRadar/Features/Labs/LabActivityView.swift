import SwiftUI

/* Favourite Lab Activity (Phase 6C): an in-app sheet listing which
   favourited labs have pending "new info", why (only the two locally
   observed signals), and when this device noticed. Strictly local —
   no notifications, no permissions, no sync. */

struct LabActivityView: View {
    let labs: [Lab]
    let isCached: Bool
    let cachedAt: Date?
    let onSelect: (String) -> Void

    @EnvironmentObject private var favorites: LabFavoritesStore
    @Environment(\.dismiss) private var dismiss

    private var entries: [(activity: LabActivity, lab: Lab?)] {
        favorites.activity.values
            .sorted { ($0.flaggedAt ?? .distantPast) > ($1.flaggedAt ?? .distantPast) }
            .map { record in (record, labs.first { $0.id == record.labID }) }
    }

    var body: some View {
        NavigationStack {
            content
                .navigationTitle("Lab Activity")
                .navigationBarTitleDisplayMode(.inline)
                .background(Theme.bg)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("Done") { dismiss() }
                            .foregroundStyle(Theme.muted)
                    }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Mark all seen") {
                            favorites.markAllSeen()
                        }
                        .foregroundStyle(favorites.activity.isEmpty ? Theme.dim : Theme.good)
                        .disabled(favorites.activity.isEmpty)
                        .accessibilityLabel("Mark all lab activity as seen")
                        .accessibilityHint("Clears every new-info indicator.")
                    }
                }
        }
        .preferredColorScheme(.dark)
    }

    @ViewBuilder
    private var content: some View {
        if favorites.favoriteIDs.isEmpty {
            EmptyStateView(
                icon: "star",
                title: "No favourite labs yet",
                message: "Star a lab in the Labs list to follow it. Activity from favourited labs shows up here."
            )
        } else if entries.isEmpty {
            VStack(spacing: 0) {
                if isCached {
                    CachedDataNotice(savedAt: cachedAt)
                        .padding(.horizontal, 16)
                        .padding(.top, 12)
                }
                EmptyStateView(
                    icon: "checkmark.circle",
                    title: "All caught up",
                    message: "No new activity from your favourite labs since your last check. New changes appear here after a refresh."
                )
            }
            .background(Theme.bg)
        } else {
            List {
                if isCached {
                    CachedDataNotice(savedAt: cachedAt)
                        .listRowBackground(Theme.panel)
                        .listRowSeparator(.hidden)
                }
                ForEach(entries, id: \.activity.id) { entry in
                    ActivityRow(
                        activity: entry.activity,
                        lab: entry.lab,
                        onAcknowledge: { favorites.clearNewInfo(for: entry.activity.labID) }
                    )
                    .contentShape(Rectangle())
                    .onTapGesture {
                        onSelect(entry.activity.labID)
                        dismiss()
                    }
                    .listRowBackground(Theme.panel)
                    .listRowSeparatorTint(Theme.line)
                }
            }
            .scrollContentBackground(.hidden)
            .background(Theme.bg)
        }
    }
}

private struct ActivityRow: View {
    let activity: LabActivity
    let lab: Lab?
    let onAcknowledge: () -> Void

    private var labName: String { lab?.name ?? activity.labID }

    /// Honest reason line — only the signals actually recorded.
    private var reasonText: String {
        let hasCount = activity.reasons.contains(.modelCountChanged)
        let hasNews = activity.reasons.contains(.newsHeadlineChanged)
        switch (hasCount, hasNews) {
        case (true, true): return "Model count and latest news changed"
        case (true, false): return "Tracked model count changed"
        case (false, true): return "Latest news headline changed"
        case (false, false): return "New info available"
        }
    }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Circle()
                .fill(Theme.labColor(lab?.color))
                .frame(width: 12, height: 12)
                .padding(.top, 4)

            VStack(alignment: .leading, spacing: 3) {
                Text(labName)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(Theme.ink)
                Text(reasonText)
                    .font(.system(size: 12.5))
                    .foregroundStyle(Theme.muted)
                if let flaggedAt = activity.flaggedAt {
                    Text("Noticed \(Fmt.relative(flaggedAt))")
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(Theme.dim)
                }
            }

            Spacer()

            Button(action: onAcknowledge) {
                Image(systemName: "checkmark.circle")
                    .font(.system(size: 17))
                    .foregroundStyle(Theme.good)
                    .frame(width: 44, height: 44)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .padding(.vertical, -8)
            .padding(.trailing, -5)
            .accessibilityLabel("Mark \(labName) activity as seen")
        }
        .padding(.vertical, 4)
        .accessibilityElement(children: .combine)
        .accessibilityLabel(
            "\(labName), \(reasonText)"
            + (activity.flaggedAt.map { ", noticed \(Fmt.relative($0))" } ?? "")
        )
        .accessibilityHint("Double tap to show this lab in the Labs list.")
    }
}
