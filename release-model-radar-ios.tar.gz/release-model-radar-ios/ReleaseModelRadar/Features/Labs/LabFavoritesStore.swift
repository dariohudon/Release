import Foundation
import SwiftUI

/* Lab favourites + in-app "new info" activity (Phases 6, 6B, 6B.1, 6C).

   Local-only, UserDefaults-backed, keyed by the API's stable lab ids.
   Activity is computed transparently: after a FRESH (not cached) load, the
   new data is compared against the previous snapshot, and a favourited lab
   is flagged with a small activity record saying WHY (model count changed /
   latest news headline changed) and WHEN this device noticed. Nothing is
   invented beyond those two locally-observed signals.

   Purely in-app — no system notifications, no permissions, no server sync.
   All UserDefaults access for favourites lives here. */

/// One favourited lab's pending "new info" record.
struct LabActivity: Codable, Equatable, Identifiable {
    enum Reason: String, Codable, CaseIterable {
        case modelCountChanged
        case newsHeadlineChanged
        /// Legacy/fallback when the specific signal wasn't recorded
        /// (e.g. flags migrated from the pre-6C format).
        case updated
    }

    let labID: String
    var reasons: Set<Reason>
    /// When THIS DEVICE first noticed the change — nil for migrated legacy
    /// flags, where claiming a time would be invented precision.
    var flaggedAt: Date?

    var id: String { labID }
}

@MainActor
final class LabFavoritesStore: ObservableObject {

    private enum Key {
        static let favorites = "labs.favorites"
        static let newInfo = "labs.newInfo" // legacy id list, kept in sync
        static let activity = "labs.activity"
        static let modelCounts = "labs.snapshot.modelCounts"
        static let latestNews = "labs.snapshot.latestNews"
    }

    @Published private(set) var favoriteIDs: Set<String>
    @Published private(set) var activity: [String: LabActivity]

    /// Ids with pending activity — same meaning as before 6C; derived so the
    /// activity records are the single source of truth.
    var newInfoLabIDs: Set<String> { Set(activity.keys) }

    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        favoriteIDs = Set(defaults.stringArray(forKey: Key.favorites) ?? [])

        if let raw = defaults.data(forKey: Key.activity),
           let decoded = try? JSONDecoder().decode([LabActivity].self, from: raw) {
            activity = Dictionary(uniqueKeysWithValues: decoded.map { ($0.labID, $0) })
        } else {
            // Migrate pre-6C flags: ids only, no recorded reason or time.
            let legacy = defaults.stringArray(forKey: Key.newInfo) ?? []
            activity = Dictionary(uniqueKeysWithValues: legacy.map {
                ($0, LabActivity(labID: $0, reasons: [.updated], flaggedAt: nil))
            })
        }
    }

    // ── Favourites ────────────────────────────────────────────────────────────

    func isFavorite(_ id: String) -> Bool {
        favoriteIDs.contains(id)
    }

    func toggle(_ id: String) {
        if favoriteIDs.contains(id) {
            favoriteIDs.remove(id)
            clearNewInfo(for: id) // unfavouriting also retires its activity
        } else {
            favoriteIDs.insert(id)
        }
        defaults.set(Array(favoriteIDs).sorted(), forKey: Key.favorites)
    }

    // ── Activity recording (in-app only) ──────────────────────────────────────

    /// Compare freshly loaded labs against the previous snapshot and flag
    /// favourited labs whose public model count changed. Call only after a
    /// fresh fetch — never for cached data.
    ///
    /// Prunes favourites whose lab id no longer exists upstream — but never
    /// on an unexpectedly empty payload (Phase 6B.1 guard).
    func recordLabsSnapshot(_ labs: [Lab]) {
        guard !labs.isEmpty else { return }

        var snapshot = stringDictionary(Key.modelCounts)
        var updated = activity
        for lab in labs {
            let fingerprint = String(lab.modelCount)
            if favoriteIDs.contains(lab.id),
               let previous = snapshot[lab.id],
               previous != fingerprint {
                updated[lab.id] = merged(updated[lab.id], labID: lab.id, adding: .modelCountChanged)
            }
            snapshot[lab.id] = fingerprint
        }

        // Cleanup: drop anything referencing labs absent from this fresh list.
        let liveIDs = Set(labs.map(\.id))
        let vanished = favoriteIDs.subtracting(liveIDs)
        if !vanished.isEmpty {
            favoriteIDs.subtract(vanished)
            defaults.set(Array(favoriteIDs).sorted(), forKey: Key.favorites)
        }
        updated = updated.filter { liveIDs.contains($0.key) }
        snapshot = snapshot.filter { liveIDs.contains($0.key) }

        defaults.set(snapshot, forKey: Key.modelCounts)
        setActivity(updated)
    }

    /// Compare freshly loaded news against the previous snapshot and flag
    /// favourited labs with a new latest headline. (Headline text is the
    /// signal — item ids are positional and can repeat across refreshes.)
    func recordNewsSnapshot(_ items: [NewsItem]) {
        var snapshot = stringDictionary(Key.latestNews)
        var updated = activity
        var seenLabs: Set<String> = []
        for item in items where !seenLabs.contains(item.lab) {
            seenLabs.insert(item.lab) // items arrive newest first
            if favoriteIDs.contains(item.lab),
               let previous = snapshot[item.lab],
               previous != item.title {
                updated[item.lab] = merged(updated[item.lab], labID: item.lab, adding: .newsHeadlineChanged)
            }
            snapshot[item.lab] = item.title
        }
        defaults.set(snapshot, forKey: Key.latestNews)
        setActivity(updated)
    }

    // ── Acknowledging activity ────────────────────────────────────────────────

    /// Acknowledge one lab's activity (row tap / per-row clear).
    func clearNewInfo(for id: String) {
        guard activity[id] != nil else { return }
        var updated = activity
        updated.removeValue(forKey: id)
        setActivity(updated)
    }

    /// Acknowledge everything ("Mark all seen").
    func markAllSeen() {
        guard !activity.isEmpty else { return }
        setActivity([:])
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private func merged(_ existing: LabActivity?, labID: String, adding reason: LabActivity.Reason) -> LabActivity {
        var record = existing ?? LabActivity(labID: labID, reasons: [], flaggedAt: Date())
        record.reasons.insert(reason)
        record.reasons.remove(.updated) // a specific signal supersedes the fallback
        if record.flaggedAt == nil { record.flaggedAt = Date() }
        return record
    }

    private func setActivity(_ updated: [String: LabActivity]) {
        guard updated != activity else { return }
        activity = updated
        if let encoded = try? JSONEncoder().encode(Array(updated.values)) {
            defaults.set(encoded, forKey: Key.activity)
        }
        // Keep the legacy id list in sync for anything still reading it.
        defaults.set(Array(updated.keys).sorted(), forKey: Key.newInfo)
    }

    private func stringDictionary(_ key: String) -> [String: String] {
        (defaults.dictionary(forKey: key) as? [String: String]) ?? [:]
    }
}
