import Foundation
import SwiftUI

/* Lab favourites + in-app "new info" indicators (Phase 6).

   Local-only, UserDefaults-backed, keyed by the API's stable lab ids.
   Indicators are computed transparently: after a FRESH (not cached) load,
   the new data is compared against the previous snapshot, and a favourited
   lab is flagged when its public model count or its latest news headline
   changed. Purely in-app — no system notifications, no permissions, no
   server sync. All UserDefaults access for favourites lives here. */

@MainActor
final class LabFavoritesStore: ObservableObject {

    private enum Key {
        static let favorites = "labs.favorites"
        static let newInfo = "labs.newInfo"
        static let modelCounts = "labs.snapshot.modelCounts"
        static let latestNews = "labs.snapshot.latestNews"
    }

    @Published private(set) var favoriteIDs: Set<String>
    @Published private(set) var newInfoLabIDs: Set<String>

    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        favoriteIDs = Set(defaults.stringArray(forKey: Key.favorites) ?? [])
        newInfoLabIDs = Set(defaults.stringArray(forKey: Key.newInfo) ?? [])
    }

    // ── Favourites ────────────────────────────────────────────────────────────

    func isFavorite(_ id: String) -> Bool {
        favoriteIDs.contains(id)
    }

    func toggle(_ id: String) {
        if favoriteIDs.contains(id) {
            favoriteIDs.remove(id)
            clearNewInfo(for: id) // unfavouriting also retires its indicator
        } else {
            favoriteIDs.insert(id)
        }
        defaults.set(Array(favoriteIDs).sorted(), forKey: Key.favorites)
    }

    // ── New-info indicators (in-app only) ─────────────────────────────────────

    /// Compare freshly loaded labs against the previous snapshot and flag
    /// favourited labs whose public model count changed. Call only after a
    /// fresh fetch — never for cached data.
    func recordLabsSnapshot(_ labs: [Lab]) {
        var snapshot = stringDictionary(Key.modelCounts)
        var flagged = newInfoLabIDs
        for lab in labs {
            let fingerprint = String(lab.modelCount)
            if favoriteIDs.contains(lab.id),
               let previous = snapshot[lab.id],
               previous != fingerprint {
                flagged.insert(lab.id)
            }
            snapshot[lab.id] = fingerprint
        }
        defaults.set(snapshot, forKey: Key.modelCounts)
        updateNewInfo(flagged)
    }

    /// Compare freshly loaded news against the previous snapshot and flag
    /// favourited labs with a new latest headline. (Headline text is the
    /// signal — item ids are positional and can repeat across refreshes.)
    func recordNewsSnapshot(_ items: [NewsItem]) {
        var snapshot = stringDictionary(Key.latestNews)
        var flagged = newInfoLabIDs
        var seenLabs: Set<String> = []
        for item in items where !seenLabs.contains(item.lab) {
            seenLabs.insert(item.lab) // items arrive newest first
            if favoriteIDs.contains(item.lab),
               let previous = snapshot[item.lab],
               previous != item.title {
                flagged.insert(item.lab)
            }
            snapshot[item.lab] = item.title
        }
        defaults.set(snapshot, forKey: Key.latestNews)
        updateNewInfo(flagged)
    }

    /// Tapping a flagged lab row acknowledges its indicator.
    func clearNewInfo(for id: String) {
        guard newInfoLabIDs.contains(id) else { return }
        newInfoLabIDs.remove(id)
        defaults.set(Array(newInfoLabIDs).sorted(), forKey: Key.newInfo)
    }

    private func updateNewInfo(_ flagged: Set<String>) {
        guard flagged != newInfoLabIDs else { return }
        newInfoLabIDs = flagged
        defaults.set(Array(flagged).sorted(), forKey: Key.newInfo)
    }

    private func stringDictionary(_ key: String) -> [String: String] {
        (defaults.dictionary(forKey: key) as? [String: String]) ?? [:]
    }
}
