import SwiftUI

/// Labs tab: every tracked lab with its color and model count.
struct LabsView: View {
    @State private var state: Loadable<LabsPayload> = .loading

    var body: some View {
        NavigationStack {
            content
                .navigationTitle("Labs")
                .background(Theme.bg)
        }
        .task { await load() }
    }

    @ViewBuilder
    private var content: some View {
        switch state {
        case .loading:
            LoadingView()
        case .failed(let message):
            ErrorView(message: message) { Task { await load(force: true) } }
        case .loaded(let payload):
            List(payload.labs) { lab in
                HStack(spacing: 12) {
                    Circle()
                        .fill(Theme.labColor(lab.color))
                        .frame(width: 12, height: 12)
                    Text(lab.name)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(Theme.ink)
                    Spacer()
                    Text("\(lab.modelCount) model\(lab.modelCount == 1 ? "" : "s")")
                        .font(.system(size: 12, design: .monospaced))
                        .foregroundStyle(Theme.dim)
                }
                .padding(.vertical, 4)
                .listRowBackground(Theme.panel)
                .listRowSeparatorTint(Theme.line)
            }
            .radarListStyle()
            .refreshable { await load(force: true) }
        }
    }

    private func load(force: Bool = false) async {
        if !force, case .loaded = state { return }
        if force { state = .loading }
        do {
            state = .loaded(try await APIClient.shared.fetch("/api/labs", as: LabsPayload.self))
        } catch {
            state = .failed(error.localizedDescription)
        }
    }
}
