import SwiftUI

/* Labs tab: every tracked lab with its color and model count.
   Phase 6: star to favourite (local-only), a favourites filter, an in-app
   "new info" dot on favourited labs whose public data changed since the
   last fresh load, and a gentle offline notice when showing cached data. */

struct LabsView: View {
    @EnvironmentObject private var favorites: LabFavoritesStore
    @State private var state: Loadable<LabsPayload> = .loading
    @State private var cachedAt: Date?
    @State private var isCached = false
    @State private var showFavoritesOnly = false

    var body: some View {
        NavigationStack {
            content
                .navigationTitle("Labs")
                .background(Theme.bg)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button {
                            showFavoritesOnly.toggle()
                        } label: {
                            Image(systemName: showFavoritesOnly ? "star.fill" : "star")
                                .foregroundStyle(showFavoritesOnly ? Theme.warn : Theme.dim)
                        }
                        .accessibilityLabel(showFavoritesOnly ? "Show all labs" : "Show favourite labs only")
                    }
                }
        }
        .task { await load() }
    }

    @ViewBuilder
    private var content: some View {
        switch state {
        case .loading:
            LoadingView()
        case .failed(let message):
            ErrorView(message: message) { Task { await load(force: true) } }
        case .loaded(let payload) where payload.labs.isEmpty:
            EmptyStateView(
                icon: "building.2",
                title: "No labs available",
                message: "Lab data may be temporarily unavailable.",
                retry: { Task { await load(force: true) } }
            )
        case .loaded(let payload):
            let visible = showFavoritesOnly
                ? payload.labs.filter { favorites.isFavorite($0.id) }
                : payload.labs

            if visible.isEmpty {
                EmptyStateView(
                    icon: "star",
                    title: "No favourite labs yet",
                    message: "Tap the star on a lab to follow it. A dot appears here when a favourited lab has new info."
                )
            } else {
                List {
                    if isCached {
                        CachedDataNotice(savedAt: cachedAt)
                            .listRowBackground(Theme.panel)
                            .listRowSeparator(.hidden)
                    }
                    ForEach(visible) { lab in
                        LabRow(
                            lab: lab,
                            isFavorite: favorites.isFavorite(lab.id),
                            hasNewInfo: favorites.newInfoLabIDs.contains(lab.id),
                            onToggleFavorite: { favorites.toggle(lab.id) }
                        )
                        .contentShape(Rectangle())
                        .onTapGesture { favorites.clearNewInfo(for: lab.id) }
                        .listRowBackground(Theme.panel)
                        .listRowSeparatorTint(Theme.line)
                    }
                }
                .radarListStyle()
                .refreshable { await load(force: true) }
            }
        }
    }

    private func load(force: Bool = false) async {
        if !force, case .loaded = state { return }
        if force { state = .loading }
        do {
            let outcome = try await APIClient.shared.fetchWithCache("/api/labs", as: LabsPayload.self)
            isCached = outcome.cachedAt != nil
            cachedAt = outcome.cachedAt
            if case .fresh = outcome.source {
                favorites.recordLabsSnapshot(outcome.value.labs)
            }
            state = .loaded(outcome.value)
        } catch {
            state = .failed(error.localizedDescription)
        }
    }
}

struct LabRow: View {
    let lab: Lab
    let isFavorite: Bool
    let hasNewInfo: Bool
    let onToggleFavorite: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Circle()
                .fill(Theme.labColor(lab.color))
                .frame(width: 12, height: 12)
            Text(lab.name)
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(Theme.ink)
            if hasNewInfo {
                HStack(spacing: 4) {
                    Circle().fill(Theme.good).frame(width: 6, height: 6)
                    Text("New info")
                        .font(.system(size: 10, weight: .semibold, design: .monospaced))
                        .foregroundStyle(Theme.good)
                }
                .accessibilityLabel("New info since your last visit")
            }
            Spacer()
            Text("\(lab.modelCount) model\(lab.modelCount == 1 ? "" : "s")")
                .font(.system(size: 12, design: .monospaced))
                .foregroundStyle(Theme.dim)
            Button(action: onToggleFavorite) {
                Image(systemName: isFavorite ? "star.fill" : "star")
                    .font(.system(size: 15))
                    .foregroundStyle(isFavorite ? Theme.warn : Theme.dim)
                    .frame(width: 34, height: 34)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel(isFavorite ? "Unfavourite \(lab.name)" : "Favourite \(lab.name)")
        }
        .padding(.vertical, 4)
    }
}
