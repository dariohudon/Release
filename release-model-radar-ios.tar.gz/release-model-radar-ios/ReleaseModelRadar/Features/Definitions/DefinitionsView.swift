import SwiftUI

/// Definitions tab: searchable plain-English glossary, tap to expand.
struct DefinitionsView: View {
    @State private var state: Loadable<DefinitionsPayload> = .loading
    @State private var query = ""
    @State private var expanded: Set<String> = []

    var body: some View {
        NavigationStack {
            content
                .navigationTitle("AI Definitions")
                .background(Theme.bg)
        }
        .task { await load() }
    }

    @ViewBuilder
    private var content: some View {
        switch state {
        case .loading:
            LoadingView()
        case .failed(let message):
            ErrorView(message: message) { Task { await load(force: true) } }
        case .loaded(let payload):
            List(filtered(payload.definitions)) { definition in
                DefinitionRow(
                    definition: definition,
                    isExpanded: expanded.contains(definition.id)
                ) {
                    withAnimation(.easeInOut(duration: 0.18)) {
                        if expanded.contains(definition.id) {
                            expanded.remove(definition.id)
                        } else {
                            expanded.insert(definition.id)
                        }
                    }
                }
                .listRowBackground(Theme.panel)
                .listRowSeparatorTint(Theme.line)
            }
            .radarListStyle()
            .searchable(text: $query, prompt: "Search terms (context, tokens, MCP…)")
            .refreshable { await load(force: true) }
            .overlay {
                if filtered(payload.definitions).isEmpty {
                    Text("No terms match.")
                        .font(.subheadline)
                        .foregroundStyle(Theme.dim)
                }
            }
        }
    }

    private func filtered(_ definitions: [Definition]) -> [Definition] {
        let q = query.trimmingCharacters(in: .whitespaces).lowercased()
        guard !q.isEmpty else { return definitions }
        return definitions.filter { d in
            d.term.lowercased().contains(q)
                || d.shortDefinition.lowercased().contains(q)
                || d.plainEnglish.lowercased().contains(q)
                || (d.aliases ?? []).contains { $0.lowercased().contains(q) }
        }
    }

    private func load(force: Bool = false) async {
        if !force, case .loaded = state { return }
        if force { state = .loading }
        do {
            state = .loaded(try await APIClient.shared.fetch("/api/definitions", as: DefinitionsPayload.self))
        } catch {
            state = .failed(error.localizedDescription)
        }
    }
}

struct DefinitionRow: View {
    let definition: Definition
    let isExpanded: Bool
    let toggle: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button(action: toggle) {
                VStack(alignment: .leading, spacing: 6) {
                    HStack(spacing: 8) {
                        Text(definition.term)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(Theme.ink)
                        Spacer(minLength: 4)
                        Pill(text: definition.category, color: Theme.dim)
                        Image(systemName: "chevron.down")
                            .font(.system(size: 11))
                            .foregroundStyle(Theme.dim)
                            .rotationEffect(.degrees(isExpanded ? 180 : 0))
                    }
                    Text(definition.shortDefinition)
                        .font(.system(size: 13))
                        .foregroundStyle(Theme.muted)
                }
            }
            .buttonStyle(.plain)

            if isExpanded {
                VStack(alignment: .leading, spacing: 12) {
                    detailBlock("PLAIN ENGLISH", definition.plainEnglish, accent: Theme.good)
                    detailBlock("WHY IT MATTERS", definition.whyItMatters, accent: Theme.warn)
                    detailBlock("EXAMPLE", definition.example, accent: Theme.dim)
                    if let related = definition.relatedTerms, !related.isEmpty {
                        Text("Related: \(related.joined(separator: " · "))")
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(Theme.dim)
                    }
                }
                .padding(.top, 2)
            }
        }
        .padding(.vertical, 4)
    }

    private func detailBlock(_ title: String, _ text: String, accent: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 9.5, weight: .semibold, design: .monospaced))
                .tracking(1.2)
                .foregroundStyle(accent)
            Text(text)
                .font(.system(size: 13))
                .foregroundStyle(Theme.ink)
        }
    }
}
