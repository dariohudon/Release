import Foundation
import SwiftUI

/* The single gateway to Tune Radar persistence. All UserDefaults access for
   preferences lives here — no scattered direct calls. Local-only by design:
   no accounts, no sync, no network. Injectable defaults keep it testable. */

@MainActor
final class TuneRadarPreferencesStore: ObservableObject {

    enum Key {
        static let usage = "tuneRadar.usage"
        static let priority = "tuneRadar.priority"
        static let seenOnboarding = "tuneRadar.hasSeenOnboarding"
    }

    @Published private(set) var preferences: TuneRadarPreferences
    @Published private(set) var hasSeenOnboarding: Bool

    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        self.preferences = TuneRadarPreferences(
            usage: defaults.string(forKey: Key.usage).flatMap(UsageFocus.init(rawValue:)),
            priority: defaults.string(forKey: Key.priority).flatMap(RadarPriority.init(rawValue:))
        )
        self.hasSeenOnboarding = defaults.bool(forKey: Key.seenOnboarding)
    }

    /// Onboarding appears while preferences are incomplete and the user has
    /// not yet seen (saved or skipped) it. Skipping keeps the app fully
    /// usable; resetting brings onboarding back.
    var shouldShowOnboarding: Bool {
        !hasSeenOnboarding && !preferences.isComplete
    }

    func setUsage(_ usage: UsageFocus?) {
        preferences.usage = usage
        if let usage {
            defaults.set(usage.rawValue, forKey: Key.usage)
        } else {
            defaults.removeObject(forKey: Key.usage)
        }
    }

    func setPriority(_ priority: RadarPriority?) {
        preferences.priority = priority
        if let priority {
            defaults.set(priority.rawValue, forKey: Key.priority)
        } else {
            defaults.removeObject(forKey: Key.priority)
        }
    }

    func completeOnboarding(usage: UsageFocus, priority: RadarPriority) {
        setUsage(usage)
        setPriority(priority)
        markOnboardingSeen()
    }

    func markOnboardingSeen() {
        hasSeenOnboarding = true
        defaults.set(true, forKey: Key.seenOnboarding)
    }

    /// Clears both answers and the seen flag — onboarding returns.
    func reset() {
        preferences = .empty
        hasSeenOnboarding = false
        defaults.removeObject(forKey: Key.usage)
        defaults.removeObject(forKey: Key.priority)
        defaults.removeObject(forKey: Key.seenOnboarding)
    }
}
