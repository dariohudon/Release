import SwiftUI

/* The "Why it matters to you" section for the model detail screen.

   - Preferences complete  → a compact card with the local explanation and a
     transparency footnote.
   - Incomplete/skipped/reset → a single gentle line pointing at Settings.
   Reads the Phase 4 store from the environment, so edits and resets in
   Settings update this section live. */

struct WhyItMattersCard: View {
    let model: RadarModel
    @EnvironmentObject private var store: TuneRadarPreferencesStore

    var body: some View {
        if let explanation = TuneRadarRecommendation.explanation(for: model, preferences: store.preferences) {
            card(explanation)
        } else {
            prompt
        }
    }

    private func card(_ explanation: TuneRadarRecommendation.Explanation) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("WHY IT MATTERS TO YOU")
                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                .tracking(1.2)
                .foregroundStyle(explanation.matchesSomething ? Theme.good : Theme.dim)
            Text(explanation.text)
                .font(.system(size: 13))
                .foregroundStyle(Theme.ink)
            Text("Based only on your Tune Radar choices, stored on this device. Adjust them in Settings.")
                .font(.system(size: 10.5))
                .foregroundStyle(Theme.dim)
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            (explanation.matchesSomething ? Theme.good : Theme.dim).opacity(0.06),
            in: RoundedRectangle(cornerRadius: 10)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke((explanation.matchesSomething ? Theme.good : Theme.dim).opacity(0.25))
        )
    }

    private var prompt: some View {
        Text("Answer the two Tune Radar questions in Settings to see why a release matters to you.")
            .font(.system(size: 12))
            .foregroundStyle(Theme.dim)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}
