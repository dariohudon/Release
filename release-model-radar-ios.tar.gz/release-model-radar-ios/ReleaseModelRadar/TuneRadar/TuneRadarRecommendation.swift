import Foundation

/* "Why it matters to you" — the personalized layer.

   A small, transparent, fully on-device mapping from (model fields ×
   Tune Radar answers) to one hedged sentence. No network, no analytics,
   no inference beyond the two choices the user made in onboarding/Settings.
   "Useful for" remains the generic public guidance; this layer only ever
   adds a personal lens on top of it. */

enum TuneRadarRecommendation {

    struct Explanation {
        let text: String
        /// True when at least one of the user's answers matched the model —
        /// callers can use this for subtle styling, never for hiding.
        let matchesSomething: Bool
    }

    /// Returns nil when preferences are incomplete (skipped onboarding,
    /// after reset) — the UI then shows nothing or a gentle Settings prompt.
    static func explanation(for model: RadarModel, preferences: TuneRadarPreferences) -> Explanation? {
        guard let usage = preferences.usage, let priority = preferences.priority else {
            return nil
        }

        let usageHit = usageMatches(usage, model)
        let priorityHit = priorityMatches(priority, model)

        let text: String
        switch (usageHit, priorityHit) {
        case (true, true):
            text = "Because you selected \(usage.label) and \(priority.label), this release may be worth watching — both show up in what it's known for."
        case (true, false):
            text = "Because you selected \(usage.label), this release may be relevant to how you use AI — though it isn't an obvious match for \(priority.label.lowercased())."
        case (false, true):
            text = "This release lines up with \(priority.label.lowercased()) from your Tune Radar answers, though \(usageDescription(usage)) isn't its obvious focus."
        case (false, false):
            text = "Based on your Tune Radar answers (\(usage.label), \(priority.label)), this release doesn't obviously match your focus — fine to skim."
        }

        return Explanation(text: text, matchesSomething: usageHit || priorityHit)
    }

    // ── Matching (simple, inspectable keyword checks) ─────────────────────────

    private static func haystack(_ model: RadarModel) -> String {
        ([model.tags.joined(separator: " "), model.bestAt, model.useFor, model.tier]
            + model.strengths)
            .joined(separator: " ")
            .lowercased()
    }

    private static func usageMatches(_ usage: UsageFocus, _ model: RadarModel) -> Bool {
        let text = haystack(model)
        switch usage {
        case .writing:
            return ["creative", "writing", "copy", "narrative", "draft"].contains(where: text.contains)
        case .coding:
            return ["coding", "code", "debug", "refactor", "engineering"].contains(where: text.contains)
        case .research:
            return ["reasoning", "research", "analysis", "math", "knowledge"].contains(where: text.contains)
        case .automation:
            return ["agent", "automation", "tool", "autonomous", "workflow"].contains(where: text.contains)
        case .everything:
            return true
        }
    }

    private static func priorityMatches(_ priority: RadarPriority, _ model: RadarModel) -> Bool {
        let text = haystack(model)
        switch priority {
        case .quality:
            return model.tags.contains("flagship") || model.tags.contains("frontier")
                || text.contains("flagship") || text.contains("frontier")
        case .value:
            return model.priceIn == "0"
                || ["cheap", "value", "cost", "price", "free"].contains(where: text.contains)
        case .speed:
            return model.tags.contains("small")
                || ["fast", "speed", "latency", "instant"].contains(where: text.contains)
        case .openness:
            return model.openWeight == true
        }
    }

    private static func usageDescription(_ usage: UsageFocus) -> String {
        switch usage {
        case .writing: return "writing and creative work"
        case .coding: return "coding and building"
        case .research: return "research and analysis"
        case .automation: return "agents and automation"
        case .everything: return "general use"
        }
    }
}
