import Foundation

/* "Why it matters to you" — the personalized layer.

   Deterministic, fully on-device template selection: the user's two Tune
   Radar answers are matched against the model's PUBLIC fields, and the
   sentence quotes the strongest concrete evidence (a strength, the tier,
   pricing, speed, open weights) plus one honest caveat. No network, no
   analytics, no inference beyond the two choices the user made.

   Product hierarchy (unchanged):
   - use/watch/ignore  = quick public usefulness label (never personalized)
   - "Useful for"      = generic public reasoning
   - this layer        = personal lens on top, 1–2 hedged sentences */

enum TuneRadarRecommendation {

    struct Explanation {
        let text: String
        /// True when at least one of the user's answers matched the model —
        /// callers can use this for subtle styling, never for hiding.
        let matchesSomething: Bool
    }

    /// Returns nil when preferences are incomplete (skipped onboarding,
    /// after reset) — the UI then shows the gentle Settings prompt.
    static func explanation(for model: RadarModel, preferences: TuneRadarPreferences) -> Explanation? {
        guard let usage = preferences.usage, let priority = preferences.priority else {
            return nil
        }

        let usageHit = usageMatches(usage, model)
        let priorityHit = priorityMatches(priority, model)

        let text: String
        switch (usageHit, priorityHit) {
        case (true, true):
            text = "Because you care about \(usageNoun(usage)) and \(priorityNoun(priority)), "
                + "\(model.name) stands out for \(usageEvidence(usage, model)), plus \(priorityEvidence(priority, model)). "
                + caveat(for: model)
        case (true, false):
            text = "Because you care about \(usageNoun(usage)), \(model.name) is relevant for \(usageEvidence(usage, model)). "
                + "It's a weaker fit for \(priorityNoun(priority)) — \(priorityMiss(priority, model))."
        case (false, true):
            text = "For \(priorityNoun(priority)), \(model.name) offers \(priorityEvidence(priority, model)) — "
                + "though its focus is \(focusSummary(model)) rather than \(usageNoun(usage)). "
                + caveat(for: model)
        case (false, false):
            text = "\(model.name) sits outside your focus (\(usageNoun(usage)), \(priorityNoun(priority))) — "
                + "it centres on \(focusSummary(model)). Worth knowing about, not an obvious fit."
        }

        return Explanation(text: text, matchesSomething: usageHit || priorityHit)
    }

    // ── Matching (unchanged keyword checks — simple and inspectable) ──────────

    private static func haystack(_ model: RadarModel) -> String {
        ([model.tags.joined(separator: " "), model.bestAt, model.useFor, model.tier]
            + model.strengths)
            .joined(separator: " ")
            .lowercased()
    }

    private static func usageKeywords(_ usage: UsageFocus) -> [String] {
        switch usage {
        case .writing: return ["creative", "writing", "copy", "narrative", "draft"]
        case .coding: return ["coding", "code", "debug", "refactor", "engineering"]
        case .research: return ["reasoning", "research", "analysis", "math", "knowledge"]
        case .automation: return ["agent", "automation", "tool", "autonomous", "workflow"]
        case .everything: return []
        }
    }

    private static func usageMatches(_ usage: UsageFocus, _ model: RadarModel) -> Bool {
        if usage == .everything { return true }
        let text = haystack(model)
        return usageKeywords(usage).contains(where: text.contains)
    }

    private static func priorityMatches(_ priority: RadarPriority, _ model: RadarModel) -> Bool {
        let text = haystack(model)
        switch priority {
        case .quality:
            return model.tags.contains("flagship") || model.tags.contains("frontier")
                || text.contains("flagship") || text.contains("frontier")
        case .value:
            return model.priceIn == "0"
                || ["cheap", "value", "cost", "price", "free"].contains(where: text.contains)
        case .speed:
            return model.tags.contains("small")
                || ["fast", "speed", "latency", "instant"].contains(where: text.contains)
        case .openness:
            return model.openWeight == true
        }
    }

    // ── Evidence (model-specific fragments quoted into the sentence) ─────────

    private static func usageEvidence(_ usage: UsageFocus, _ model: RadarModel) -> String {
        if usage == .everything {
            return lowercasedFirst(clip(model.bestAt))
        }
        let keywords = usageKeywords(usage)
        if let strength = model.strengths.first(where: { s in
            keywords.contains(where: s.lowercased().contains)
        }) {
            return "strengths like \u{201C}\(clip(strength))\u{201D}"
        }
        if keywords.contains(where: model.bestAt.lowercased().contains) {
            return lowercasedFirst(clip(model.bestAt))
        }
        return lowercasedFirst(clip(model.useFor))
    }

    private static func priorityEvidence(_ priority: RadarPriority, _ model: RadarModel) -> String {
        switch priority {
        case .quality:
            let tier = model.tier.lowercased()
            if tier.contains("flagship") || tier.contains("frontier") {
                return "its \(clip(tier, 40)) positioning"
            }
            if let index = model.index {
                return "an intelligence index of \(trimmedNumber(index))"
            }
            return "its top-tier reputation"
        case .value:
            if model.priceIn == "0" {
                return "being free to self-host"
            }
            if let price = model.priceLine {
                return "pricing around \(price)"
            }
            if let note = model.priceNote {
                return lowercasedFirst(clip(note))
            }
            return "its value positioning"
        case .speed:
            if let speed = model.speed, !speed.isEmpty, speed != "—" {
                return "a \u{201C}\(lowercasedFirst(speed))\u{201D} speed profile"
            }
            return "its small, low-latency design"
        case .openness:
            return "open weights you can run or adapt outside closed hosted APIs"
        }
    }

    /// Why the model is a weaker fit for the chosen priority — the honest
    /// counterweight when only the usage focus matched.
    private static func priorityMiss(_ priority: RadarPriority, _ model: RadarModel) -> String {
        switch priority {
        case .quality: return "it isn't positioned as a frontier flagship"
        case .value: return "price isn't its main draw"
        case .speed: return "speed isn't what it's known for"
        case .openness: return "it's closed or API-hosted, so you can't run it yourself"
        }
    }

    /// One honest caveat, strongest signal first: horizon status, the public
    /// ignore label, or the model's own first watch-out.
    private static func caveat(for model: RadarModel) -> String {
        if model.status == "horizon" {
            return "Caveat: it's still on the horizon, so there's nothing to adopt yet."
        }
        if model.verdict == "ignore" {
            return "Caveat: its public label is ignore, so treat this as context rather than a tool to pick up."
        }
        if let watchout = model.watchouts.first {
            return "Caveat: \(lowercasedFirst(clip(watchout)))."
        }
        return "As always, weigh it against what you already use."
    }

    private static func focusSummary(_ model: RadarModel) -> String {
        lowercasedFirst(clip(model.bestAt, 56))
    }

    // ── Wording nouns ─────────────────────────────────────────────────────────

    private static func usageNoun(_ usage: UsageFocus) -> String {
        switch usage {
        case .writing: return "writing"
        case .coding: return "coding"
        case .research: return "research and analysis"
        case .automation: return "agents and automation"
        case .everything: return "broad everyday use"
        }
    }

    private static func priorityNoun(_ priority: RadarPriority) -> String {
        switch priority {
        case .quality: return "top quality"
        case .value: return "price and value"
        case .speed: return "speed"
        case .openness: return "privacy and open weights"
        }
    }

    // ── Small string helpers ──────────────────────────────────────────────────

    private static func clip(_ s: String, _ max: Int = 64) -> String {
        var t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.hasSuffix(".") { t = String(t.dropLast()) }
        guard t.count > max else { return t }
        var head = String(t.prefix(max))
        if let lastSpace = head.lastIndex(of: " ") {
            head = String(head[..<lastSpace]) // never cut mid-word
        }
        return head.trimmingCharacters(in: .whitespaces) + "…"
    }

    private static func lowercasedFirst(_ s: String) -> String {
        guard let first = s.first else { return s }
        return first.lowercased() + s.dropFirst()
    }

    private static func trimmedNumber(_ value: Double) -> String {
        value.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(value)) : String(value)
    }
}
