import Foundation

/* Tune Radar preferences — the two onboarding questions.
   Local-only: stored in UserDefaults via TuneRadarPreferencesStore, never
   sent anywhere. These will power future "Why it matters to you" guidance;
   public generic guidance stays "Useful for". */

enum UsageFocus: String, CaseIterable, Identifiable, Codable {
    case writing
    case coding
    case research
    case automation
    case everything

    var id: String { rawValue }

    var label: String {
        switch self {
        case .writing: return "Writing & content"
        case .coding: return "Coding & building"
        case .research: return "Research & analysis"
        case .automation: return "Automation & agents"
        case .everything: return "A bit of everything"
        }
    }
}

enum RadarPriority: String, CaseIterable, Identifiable, Codable {
    case quality
    case value
    case speed
    case openness

    var id: String { rawValue }

    var label: String {
        switch self {
        case .quality: return "Top quality"
        case .value: return "Price & value"
        case .speed: return "Speed"
        case .openness: return "Privacy & open weights"
        }
    }
}

struct TuneRadarPreferences: Equatable {
    var usage: UsageFocus?
    var priority: RadarPriority?

    var isComplete: Bool { usage != nil && priority != nil }

    static let empty = TuneRadarPreferences(usage: nil, priority: nil)
}
