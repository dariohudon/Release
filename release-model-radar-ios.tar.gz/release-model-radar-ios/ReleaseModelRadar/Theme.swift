import SwiftUI

/// Design tokens mirroring the web app's `app/radar.css` dark navy palette.
extension Color {
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }
}

enum Theme {
    static let bg = Color(hex: 0x0E1424)
    static let panel = Color(hex: 0x141C30)
    static let raised = Color(hex: 0x1B2540)
    static let line = Color(hex: 0x28324E)
    static let ink = Color(hex: 0xE8ECF6)
    static let muted = Color(hex: 0x8A95B2)
    static let dim = Color(hex: 0x5C668A)
    static let good = Color(hex: 0x5EEAD4)
    static let warn = Color(hex: 0xF0B36B)

    /// Parses the API's `#RRGGBB` lab colors; falls back to dim.
    static func labColor(_ hexString: String?) -> Color {
        guard let hexString,
              hexString.hasPrefix("#"),
              hexString.count == 7,
              let value = UInt32(hexString.dropFirst(), radix: 16)
        else { return dim }
        return Color(hex: value)
    }
}

/// Date helpers for the API's ISO timestamps.
enum Fmt {
    static func isoDate(_ string: String?) -> Date? {
        guard let string else { return nil }
        let withFraction = ISO8601DateFormatter()
        withFraction.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = withFraction.date(from: string) { return date }
        return ISO8601DateFormatter().date(from: string)
    }

    static func shortDate(_ date: Date) -> String {
        date.formatted(.dateTime.month(.abbreviated).day())
    }

    static func time(_ date: Date) -> String {
        date.formatted(.dateTime.hour().minute())
    }

    static func relative(_ date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}
