import Foundation

/* Read-only client for the public Release Model Radar API.
   No keys, no auth, no mutation — the web app is the source of truth.
   MVP cache policy: the last successful response per endpoint is kept in
   memory only and used as a fallback when the network fails. */

enum APIError: LocalizedError {
    case badURL
    case http(Int)
    case api(String)
    case decoding
    case network(String)

    var errorDescription: String? {
        switch self {
        case .badURL: return "Invalid URL."
        case .http(let code): return "Server returned HTTP \(code)."
        case .api(let message): return message
        case .decoding: return "Unexpected response format."
        case .network(let message): return message
        }
    }
}

actor APIClient {
    static let shared = APIClient()
    static let baseURL = URL(string: "https://release.brightening.ca")!

    private let session: URLSession
    private var memoryCache: [String: Data] = [:]

    init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 15
        session = URLSession(configuration: config)
    }

    func fetch<T: Decodable>(_ path: String, as type: T.Type) async throws -> T {
        guard let url = URL(string: path, relativeTo: Self.baseURL) else {
            throw APIError.badURL
        }
        do {
            let (data, response) = try await session.data(from: url)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                // The API uses the failure envelope with non-2xx codes (e.g.
                // 404 for "no update check recorded yet") — surface its safe
                // message rather than a bare status code where possible.
                if let envelope = try? JSONDecoder().decode(Envelope<T>.self, from: data),
                   envelope.ok == false {
                    throw APIError.api(envelope.error ?? "Request failed.")
                }
                throw APIError.http(http.statusCode)
            }
            memoryCache[path] = data
            return try decodeEnvelope(data)
        } catch let error as APIError {
            throw error
        } catch {
            if let cached = memoryCache[path], let value: T = try? decodeEnvelope(cached) {
                return value
            }
            throw APIError.network(error.localizedDescription)
        }
    }

    private func decodeEnvelope<T: Decodable>(_ data: Data) throws -> T {
        guard let envelope = try? JSONDecoder().decode(Envelope<T>.self, from: data) else {
            throw APIError.decoding
        }
        guard envelope.ok, let payload = envelope.data else {
            throw APIError.api(envelope.error ?? "Request failed.")
        }
        return payload
    }
}

/// Simple three-state wrapper for screen loading.
enum Loadable<T> {
    case loading
    case loaded(T)
    case failed(String)
}
