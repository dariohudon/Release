import Foundation

/* Read-only client for the public Release Model Radar API.
   No keys, no auth, no mutation — the web app is the source of truth.

   Cache policy (Phase 6): a response is cached in memory AND on disk only
   after it fully decodes, so failed requests or bad payloads never replace
   good data. When a fetch fails, the last good response is returned instead
   and the caller is told it is cached (with its saved date) so screens can
   show a gentle offline notice. */

enum APIError: LocalizedError {
    case badURL
    case http(Int)
    case api(String)
    case decoding
    case network(String)

    var errorDescription: String? {
        switch self {
        case .badURL: return "Invalid URL."
        case .http(let code): return "Server returned HTTP \(code)."
        case .api(let message): return message
        case .decoding: return "Unexpected response format."
        case .network(let message): return message
        }
    }
}

/// Where a returned value came from.
enum DataSource {
    case fresh
    case cached(savedAt: Date)
}

struct FetchOutcome<T> {
    let value: T
    let source: DataSource

    var cachedAt: Date? {
        if case .cached(let savedAt) = source { return savedAt }
        return nil
    }
}

actor APIClient {
    static let shared = APIClient()
    static let baseURL = URL(string: "https://release.brightening.ca")!

    private let session: URLSession
    private let diskCache: LocalAPIResponseCache
    private var memoryCache: [String: (data: Data, savedAt: Date)] = [:]

    /// Configuration and disk cache are injectable for tests; production
    /// callers use the defaults.
    init(configuration: URLSessionConfiguration = .default,
         diskCache: LocalAPIResponseCache = .shared) {
        configuration.timeoutIntervalForRequest = 15
        session = URLSession(configuration: configuration)
        self.diskCache = diskCache
    }

    /// Convenience for callers that don't care about the source.
    func fetch<T: Decodable>(_ path: String, as type: T.Type) async throws -> T {
        try await fetchWithCache(path, as: type).value
    }

    /// Fetch with last-good-response fallback. Throws only when there is no
    /// usable cache, or when the server gave an authoritative ok:false
    /// answer (which should not be masked by stale data).
    func fetchWithCache<T: Decodable>(_ path: String, as type: T.Type) async throws -> FetchOutcome<T> {
        guard let url = URL(string: path, relativeTo: Self.baseURL) else {
            throw APIError.badURL
        }
        do {
            let (data, response) = try await session.data(from: url)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                if let envelope = try? JSONDecoder().decode(Envelope<T>.self, from: data),
                   envelope.ok == false {
                    throw APIError.api(envelope.error ?? "Request failed.")
                }
                throw APIError.http(http.statusCode)
            }
            // Decode FIRST — only a fully decoded response earns the cache.
            let value: T = try decodeEnvelope(data)
            memoryCache[path] = (data, Date())
            await diskCache.save(data, for: path)
            return FetchOutcome(value: value, source: .fresh)
        } catch let error as APIError {
            if case .api = error { throw error } // authoritative server answer
            if let fallback: FetchOutcome<T> = await cachedFallback(for: path) { return fallback }
            throw error
        } catch {
            if let fallback: FetchOutcome<T> = await cachedFallback(for: path) { return fallback }
            throw APIError.network(error.localizedDescription)
        }
    }

    private func cachedFallback<T: Decodable>(for path: String) async -> FetchOutcome<T>? {
        if let entry = memoryCache[path], let value: T = try? decodeEnvelope(entry.data) {
            return FetchOutcome(value: value, source: .cached(savedAt: entry.savedAt))
        }
        if let disk = await diskCache.load(for: path),
           let value: T = try? decodeEnvelope(disk.data) {
            memoryCache[path] = (disk.data, disk.savedAt) // hydrate for this session
            return FetchOutcome(value: value, source: .cached(savedAt: disk.savedAt))
        }
        return nil
    }

    private func decodeEnvelope<T: Decodable>(_ data: Data) throws -> T {
        let envelope: Envelope<T>
        do {
            envelope = try JSONDecoder().decode(Envelope<T>.self, from: data)
        } catch {
            #if DEBUG
            print("APIClient: envelope decode failed —", error)
            #endif
            throw APIError.decoding
        }
        guard envelope.ok, let payload = envelope.data else {
            throw APIError.api(envelope.error ?? "Request failed.")
        }
        return payload
    }
}

/// Simple three-state wrapper for screen loading.
enum Loadable<T> {
    case loading
    case loaded(T)
    case failed(String)
}
