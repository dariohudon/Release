import Foundation

/* Persistent last-good response cache (Phase 6).

   Local-only disk cache in Library/Caches. APIClient writes here ONLY after
   a response has fully decoded, so a failed request or undecodable payload
   can never replace good data. Each entry records when it was saved so the
   UI can show "Offline — last updated …". Nothing here ever leaves the
   device, and the cache holds only public read-only API data. */

actor LocalAPIResponseCache {
    static let shared = LocalAPIResponseCache()

    private struct Entry: Codable {
        let savedAt: Date
        let data: Data
    }

    private let directory: URL

    init(directoryName: String = "APIResponseCache") {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        directory = base.appendingPathComponent(directoryName, isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }

    /// Called only with data that already decoded successfully.
    func save(_ data: Data, for path: String) {
        let entry = Entry(savedAt: Date(), data: data)
        guard let encoded = try? JSONEncoder().encode(entry) else { return }
        try? encoded.write(to: fileURL(for: path), options: .atomic)
    }

    func load(for path: String) -> (data: Data, savedAt: Date)? {
        guard let raw = try? Data(contentsOf: fileURL(for: path)),
              let entry = try? JSONDecoder().decode(Entry.self, from: raw)
        else { return nil }
        return (entry.data, entry.savedAt)
    }

    private func fileURL(for path: String) -> URL {
        let safeName = String(path.map { $0.isLetter || $0.isNumber ? $0 : "-" })
        return directory.appendingPathComponent(safeName + ".json")
    }
}
