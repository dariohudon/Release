import Foundation

/* Decodable mirrors of the Release Model Radar public API.
   Source of truth: the web app's lib/models/data.ts, lib/definitions/data.ts,
   lib/news/fetchNews.ts, and lib/api/types.ts. */

/// Shared response envelope: { ok, generatedAt, count, data } / { ok:false, error }.
/// Everything except `ok` is tolerant of omission so a slightly off-spec
/// failure envelope still decodes instead of masking the real error.
struct Envelope<T: Decodable>: Decodable {
    let ok: Bool
    let generatedAt: String?
    let count: Int?
    let data: T?
    let error: String?
}

// ── /api/models ───────────────────────────────────────────────────────────────

struct Sentiment: Decodable, Hashable {
    let score: Int
    let label: String
    let summary: String
}

struct RadarModel: Decodable, Identifiable, Hashable {
    let id: String
    let lab: String
    let name: String
    let tags: [String]
    let released: String
    let status: String   // new | live | horizon
    let verdict: String  // use | watch | ignore — at-a-glance public usefulness label, explained by `useFor`; never personalized
    let confidence: String?
    let tier: String
    let bestAt: String
    let index: Double?
    let indexNote: String?
    let priceIn: String?
    let priceOut: String?
    let priceNote: String?
    let context: String?
    let speed: String?
    let strengths: [String]
    let watchouts: [String]
    let useFor: String
    // Note: the API also serves a personalized `forDario` field; this app
    // deliberately does not decode or render it — public/product-safe only.
    let sentiment: Sentiment
    let link: String
    let openWeight: Bool?

    var priceLine: String? {
        guard let priceIn else { return nil }
        let inLabel = priceIn == "0" ? "free" : "$\(priceIn)"
        guard let priceOut, priceOut != "0" else { return inLabel }
        return "\(inLabel) → $\(priceOut) /M"
    }
}

struct ModelsPayload: Decodable {
    let models: [RadarModel]
    let countsByLab: [String: Int]?
    let countsByStatus: [String: Int]?
    let countsByVerdict: [String: Int]?
}

// ── /api/labs ─────────────────────────────────────────────────────────────────

struct Lab: Decodable, Identifiable, Hashable {
    let id: String
    let name: String
    let color: String
    let modelCount: Int
}

struct LabsPayload: Decodable {
    let labs: [Lab]
}

// ── /api/definitions ──────────────────────────────────────────────────────────

struct Definition: Decodable, Identifiable, Hashable {
    let id: String
    let term: String
    let shortDefinition: String
    let plainEnglish: String
    let whyItMatters: String
    let example: String
    let category: String
    let aliases: [String]?
    let relatedTerms: [String]?
    let freshness: String?
}

struct DefinitionsPayload: Decodable {
    let definitions: [Definition]
    let categories: [String]
}

// ── /api/update-status ────────────────────────────────────────────────────────

struct UpdateStatus: Decodable {
    let lastCheckedAt: String
    let sourcesChecked: Int
    let candidatesFound: Int
    let newCandidates: Int
    let failedSources: Int
}

// ── /api/news ─────────────────────────────────────────────────────────────────

struct NewsItem: Decodable, Identifiable, Hashable {
    let id: String
    let lab: String
    let labName: String
    let title: String
    let url: String
    let source: String
    let sourceType: String // official | news-search | fallback
    let publishedAt: String?
    let snippet: String?
}

struct NewsPayload: Decodable {
    let items: [NewsItem]
    let liveLabs: Int?
    let failedLabs: [String]?
    let feedGeneratedAt: String?
}
