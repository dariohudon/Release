import SwiftUI

/// Centered loading state.
struct LoadingView: View {
    var body: some View {
        VStack(spacing: 12) {
            ProgressView()
            Text("Loading…")
                .font(.footnote.monospaced())
                .foregroundStyle(Theme.dim)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

/// Centered error state with a retry button.
struct ErrorView: View {
    let message: String
    let retry: () -> Void

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: "wifi.exclamationmark")
                .font(.title)
                .foregroundStyle(Theme.dim)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(Theme.muted)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            Button(action: retry) {
                Text("Retry")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 22)
                    .padding(.vertical, 9)
                    .background(Theme.raised, in: RoundedRectangle(cornerRadius: 9))
                    .overlay(RoundedRectangle(cornerRadius: 9).stroke(Theme.line))
            }
            .buttonStyle(.plain)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

/// Small uppercase mono pill, the iOS cousin of the web app's tags.
struct Pill: View {
    let text: String
    var color: Color = Theme.dim

    var body: some View {
        Text(text.uppercased())
            .font(.system(size: 9.5, weight: .semibold, design: .monospaced))
            .tracking(0.8)
            .foregroundStyle(color)
            .padding(.horizontal, 7)
            .padding(.vertical, 3)
            .overlay(RoundedRectangle(cornerRadius: 5).stroke(color.opacity(0.45)))
    }
}

extension RadarModel {
    var verdictColor: Color {
        switch verdict {
        case "use": return Theme.good
        case "watch": return Theme.warn
        default: return Theme.dim
        }
    }

    var statusLabel: String {
        switch status {
        case "new": return "Just shipped"
        case "live": return "Live now"
        case "horizon": return "On the horizon"
        default: return status
        }
    }
}

/// Applies the shared dark list chrome.
extension View {
    func radarListStyle() -> some View {
        self
            .scrollContentBackground(.hidden)
            .background(Theme.bg)
    }
}
