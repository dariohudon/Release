import SwiftUI

@main
struct ReleaseModelRadarApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
                .preferredColorScheme(.dark)
                .tint(Theme.good)
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            ModelsView()
                .tabItem { Label("Radar", systemImage: "dot.radiowaves.left.and.right") }
            LabsView()
                .tabItem { Label("Labs", systemImage: "building.2") }
            DefinitionsView()
                .tabItem { Label("Definitions", systemImage: "book") }
            NewsView()
                .tabItem { Label("News", systemImage: "newspaper") }
        }
    }
}

#Preview {
    RootView().preferredColorScheme(.dark)
}
