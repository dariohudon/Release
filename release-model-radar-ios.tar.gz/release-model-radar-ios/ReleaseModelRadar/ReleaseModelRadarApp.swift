import SwiftUI

@main
struct ReleaseModelRadarApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
                .preferredColorScheme(.dark)
                .tint(Theme.good)
        }
    }
}

struct RootView: View {
    @StateObject private var tuneRadar = TuneRadarPreferencesStore()

    var body: some View {
        TabView {
            ModelsView()
                .tabItem { Label("Radar", systemImage: "dot.radiowaves.left.and.right") }
            LabsView()
                .tabItem { Label("Labs", systemImage: "building.2") }
            DefinitionsView()
                .tabItem { Label("Definitions", systemImage: "book") }
            NewsView()
                .tabItem { Label("News", systemImage: "newspaper") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .environmentObject(tuneRadar)
        // First launch (or after a reset): present Tune Radar while
        // preferences are incomplete and the user hasn't saved or skipped.
        .fullScreenCover(isPresented: showOnboarding) {
            TuneRadarOnboardingView()
                .environmentObject(tuneRadar)
                .preferredColorScheme(.dark)
        }
    }

    private var showOnboarding: Binding<Bool> {
        Binding(
            get: { tuneRadar.shouldShowOnboarding },
            set: { _ in } // dismissal is driven by the store (save or skip)
        )
    }
}

#Preview {
    RootView().preferredColorScheme(.dark)
}
